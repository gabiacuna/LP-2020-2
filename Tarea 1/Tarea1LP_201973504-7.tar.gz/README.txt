Gabriela Acuña 201973504-7

Intente tomar en cuanta todas las consideraciones agregadas en el foro, pero quizas se me paso un espacio por ahí.

Linea de comando:
    python3 reconocedor.py